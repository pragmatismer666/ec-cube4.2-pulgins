<?php

/*
 * This file is part of EC-CUBE
 *
 * Copyright(c) EC-CUBE CO.,LTD. All Rights Reserved.
 *
 * http://www.ec-cube.co.jp/
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Plugin\StripeRec\Repository;

use Plugin\StripeRec\Entity\PurchasePoint;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Query;
use Eccube\Repository\AbstractRepository;
// use Symfony\Bridge\Doctrine\RegistryInterface;
use Doctrine\Persistence\ManagerRegistry as RegistryInterface;
/**
 * PurchasePointRepository
 */
class PurchasePointRepository extends AbstractRepository
{
    /**
     * OrderStatusRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, PurchasePoint::class);
    }
}
