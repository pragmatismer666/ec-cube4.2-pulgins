<?php


namespace Plugin\PointsOnReferral\Event;


final class PointsOnReferralEvents {

    const FRONT_MYPAGE_REFERRAL_INDEX_INITIALIZE = "front.mypage.referral.index.initialize";

    const FRONT_MYPAGE_REFERRAL_INDEX_COMPLETE = "front.mypage.referral.index.complete";

}
